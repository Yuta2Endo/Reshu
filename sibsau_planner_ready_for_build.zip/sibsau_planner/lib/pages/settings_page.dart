import 'package:flutter/material.dart';

import '../app_state.dart';
import '../util.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage(this.s, {super.key});
  final AppState s;

  static const _seeds = [0xFF3F51B5, 0xFF00897B, 0xFFE53935, 0xFF8E24AA, 0xFFF57C00, 0xFF1E88E5];

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) {
        final week = weekParity(campusNow(), invert: s.invertWeek);
        return Scaffold(
          appBar: AppBar(title: const Text('Настройки')),
          body: ListView(padding: const EdgeInsets.all(16), children: [
            Text('Тема', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            SegmentedButton<ThemeMode>(
              segments: const [
                ButtonSegment(value: ThemeMode.system, label: Text('Авто')),
                ButtonSegment(value: ThemeMode.light, label: Text('Светлая')),
                ButtonSegment(value: ThemeMode.dark, label: Text('Тёмная')),
              ],
              selected: {s.themeMode},
              onSelectionChanged: (v) => s.setTheme(v.first),
            ),
            const SizedBox(height: 16),
            Wrap(spacing: 12, children: [
              for (final c in _seeds)
                GestureDetector(
                  onTap: () => s.setSeed(c),
                  child: CircleAvatar(
                    backgroundColor: Color(c),
                    child: s.seed == c ? const Icon(Icons.check, color: Colors.white) : null,
                  ),
                ),
            ]),
            const Divider(height: 32),
            SwitchListTile(
              title: const Text('Напоминать о парах'),
              subtitle: const Text('Уведомление перед началом занятия'),
              value: s.notify,
              onChanged: s.setNotify,
            ),
            ListTile(
              enabled: s.notify,
              title: const Text('За сколько минут'),
              trailing: DropdownButton<int>(
                value: s.notifyMin,
                items: [for (final m in [5, 10, 15, 30, 60]) DropdownMenuItem(value: m, child: Text('$m мин'))],
                onChanged: s.notify ? (v) => s.setNotifyMin(v!) : null,
              ),
            ),
            const Divider(height: 32),
            SwitchListTile(
              title: const Text('Инвертировать чётность недель'),
              subtitle: Text('Сейчас идёт $week-я неделя. Включите, если на сайте наоборот.'),
              value: s.invertWeek,
              onChanged: s.setInvertWeek,
            ),
            const Divider(height: 32),
            const Text(
              'Неофициальное приложение. Расписание и новости берутся с открытых сайтов СибГУ.',
            ),
          ]),
        );
      },
    );
  }
}
