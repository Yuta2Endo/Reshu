import 'package:flutter/material.dart';

import '../app_state.dart';
import '../models.dart';
import '../sources.dart';

class GroupsPage extends StatefulWidget {
  const GroupsPage(this.s, {super.key});
  final AppState s;
  @override
  State<GroupsPage> createState() => _GroupsPageState();
}

class _GroupsPageState extends State<GroupsPage> {
  final _c = TextEditingController();
  List<GroupRef> _res = [];
  bool _busy = false;
  String? _err;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final q = _c.text.trim();
    if (q.isEmpty) return;
    setState(() {
      _busy = true;
      _err = null;
    });
    try {
      final r = await widget.s.searchGroups(q);
      if (!mounted) return;
      setState(() => _res = r);
    } catch (e) {
      if (!mounted) return;
      setState(() => _err = 'Поиск не удался: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _pick(GroupRef g) async {
    await widget.s.selectGroup(g);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return Scaffold(
      appBar: AppBar(title: const Text('Группа')),
      body: ListenableBuilder(
        listenable: s,
        builder: (context, _) => ListView(padding: const EdgeInsets.all(16), children: [
          TextField(
            controller: _c,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _search(),
            decoration: InputDecoration(
              hintText: 'Номер группы или фамилия преподавателя',
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(icon: const Icon(Icons.search), onPressed: _search),
            ),
          ),
          if (_busy) const LinearProgressIndicator(),
          if (_err != null)
            Padding(padding: const EdgeInsets.all(8), child: Text(_err!)),
          if (_res.isNotEmpty) ...[
            const _Header('Результаты'),
            for (final g in _res)
              ListTile(title: Text(g.name), onTap: () => _pick(g)),
          ],
          if (s.favorites.isNotEmpty) ...[
            const _Header('Избранное'),
            for (final g in s.favorites)
              ListTile(
                leading: Icon(g == s.active ? Icons.star : Icons.star_border),
                title: Text(g.name),
                trailing: IconButton(
                    icon: const Icon(Icons.close), onPressed: () => s.removeFavorite(g)),
                onTap: () => _pick(g),
              ),
          ],
          const _Header('Без интернета'),
          ListTile(
            leading: const Icon(Icons.science_outlined),
            title: const Text('Демо-расписание'),
            subtitle: const Text('Чтобы попробовать приложение'),
            onTap: () => _pick(DemoSource.group),
          ),
        ]),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 16, 4, 4),
        child: Text(text, style: Theme.of(context).textTheme.titleSmall),
      );
}
