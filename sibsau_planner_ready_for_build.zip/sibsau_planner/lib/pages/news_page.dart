import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../app_state.dart';

class NewsPage extends StatelessWidget {
  const NewsPage(this.s, {super.key});
  final AppState s;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: const Text('Новости СибГУ')),
        body: RefreshIndicator(
          onRefresh: s.refreshNews,
          child: ListView(padding: const EdgeInsets.all(16), children: [
            if (s.newsLoading && s.news.isEmpty)
              const Center(child: Padding(padding: EdgeInsets.all(32), child: CircularProgressIndicator())),
            if (s.newsError != null)
              Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(s.newsError!)),
            for (final n in s.news)
              Card(
                child: ListTile(
                  title: Text(n.title),
                  trailing: const Icon(Icons.open_in_new, size: 18),
                  onTap: () => launchUrl(Uri.parse(n.url), mode: LaunchMode.externalApplication),
                ),
              ),
          ]),
        ),
      ),
    );
  }
}
