import 'package:flutter/material.dart';

import '../app_state.dart';
import '../models.dart';
import '../util.dart';
import 'groups_page.dart';

class TimetablePage extends StatefulWidget {
  const TimetablePage(this.s, {super.key});
  final AppState s;
  @override
  State<TimetablePage> createState() => _TimetablePageState();
}

class _TimetablePageState extends State<TimetablePage> {
  late int _day;
  late int _week;

  @override
  void initState() {
    super.initState();
    final n = campusNow();
    _day = n.weekday == 7 ? 1 : n.weekday;
    _week = weekParity(n, invert: widget.s.invertWeek);
  }

  void _pickGroup() => Navigator.push(
      context, MaterialPageRoute(builder: (_) => GroupsPage(widget.s)));

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.s,
      builder: (context, _) {
        final s = widget.s;
        final cs = Theme.of(context).colorScheme;
        final now = campusNow();
        final nowMin = now.hour * 60 + now.minute;
        final isToday = _day == now.weekday &&
            _week == weekParity(now, invert: s.invertWeek);
        final list = s.lessonsFor(_day, _week);
        final next = s.nextLesson();

        return Scaffold(
          appBar: AppBar(
            title: InkWell(
              onTap: _pickGroup,
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Flexible(
                    child: Text(s.active?.name ?? 'Выберите группу',
                        overflow: TextOverflow.ellipsis)),
                const Icon(Icons.arrow_drop_down),
              ]),
            ),
            actions: [
              if (s.loading)
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
                )
              else
                IconButton(icon: const Icon(Icons.refresh), onPressed: s.refreshTimetable),
            ],
          ),
          body: s.active == null
              ? Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.school_outlined, size: 64),
                    const SizedBox(height: 12),
                    const Text('Выберите группу, чтобы увидеть расписание'),
                    const SizedBox(height: 12),
                    FilledButton(onPressed: _pickGroup, child: const Text('Найти группу')),
                  ]),
                )
              : RefreshIndicator(
                  onRefresh: s.refreshTimetable,
                  child: ListView(padding: const EdgeInsets.all(16), children: [
                    if (next != null) _NextCard(next.lesson, next.date, now),
                    if (s.error != null)
                      Card(
                        color: cs.errorContainer,
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Text(s.error!, style: TextStyle(color: cs.onErrorContainer)),
                        ),
                      ),
                    if (s.updatedAt != null)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Text(
                          'Обновлено ${s.updatedAt!.day} ${monthShort[s.updatedAt!.month - 1]}, '
                          '${two(s.updatedAt!.hour)}:${two(s.updatedAt!.minute)}',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ),
                    SegmentedButton<int>(
                      segments: const [
                        ButtonSegment(value: 1, label: Text('1 неделя')),
                        ButtonSegment(value: 2, label: Text('2 неделя')),
                      ],
                      selected: {_week},
                      onSelectionChanged: (v) => setState(() => _week = v.first),
                    ),
                    const SizedBox(height: 8),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(children: [
                        for (var d = 1; d <= 6; d++)
                          Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: ChoiceChip(
                              label: Text(weekdayShort[d - 1]),
                              selected: _day == d,
                              onSelected: (_) => setState(() => _day = d),
                            ),
                          ),
                      ]),
                    ),
                    const SizedBox(height: 8),
                    if (list.isEmpty)
                      const Padding(
                        padding: EdgeInsets.all(32),
                        child: Center(child: Text('В этот день пар нет 🎉')),
                      ),
                    for (final l in list)
                      _LessonTile(
                        l,
                        current: isToday && l.startMinutes <= nowMin && nowMin < l.endMinutes,
                      ),
                  ]),
                ),
        );
      },
    );
  }
}

class _NextCard extends StatelessWidget {
  const _NextCard(this.l, this.date, this.now);
  final Lesson l;
  final DateTime date, now;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final t = Theme.of(context).textTheme;
    return Card(
      color: cs.primaryContainer,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Следующая пара', style: t.labelLarge?.copyWith(color: cs.onPrimaryContainer)),
          const SizedBox(height: 4),
          Text(l.title, style: t.titleLarge?.copyWith(color: cs.onPrimaryContainer)),
          const SizedBox(height: 4),
          Text(
            '${relativeDay(date, now)} · ${l.start}–${l.end}'
            '${l.room.isEmpty ? '' : ' · ауд. ${l.room}'}',
            style: t.bodyMedium?.copyWith(color: cs.onPrimaryContainer),
          ),
        ]),
      ),
    );
  }
}

class _LessonTile extends StatelessWidget {
  const _LessonTile(this.l, {required this.current});
  final Lesson l;
  final bool current;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final t = Theme.of(context).textTheme;
    final meta = [l.type, if (l.room.isNotEmpty) 'ауд. ${l.room}']
        .where((e) => e.isNotEmpty)
        .join(' · ');
    return Card(
      color: current ? cs.secondaryContainer : cs.surfaceContainerHighest.withOpacity(0.5),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(
            width: 56,
            child: Column(children: [
              Text(l.start, style: t.titleMedium),
              Text(l.end, style: t.bodySmall),
            ]),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(l.title, style: t.titleMedium),
              if (meta.isNotEmpty) Text(meta, style: t.bodyMedium),
              if (l.teacher.isNotEmpty) Text(l.teacher, style: t.bodySmall),
              if (current)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text('Идёт сейчас', style: t.labelMedium?.copyWith(color: cs.primary)),
                ),
            ]),
          ),
        ]),
      ),
    );
  }
}
